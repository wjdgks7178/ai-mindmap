# Copyright (c) Meta Platforms, Inc. and affiliates.
#
# This source code is licensed under the MIT license found in the
# LICENSE file in the root directory of this source tree.


from __future__ import annotations

import logging

from balance.balance_frame import BalanceFrame  # noqa
from balance.balancedf_class import (  # noqa
    BalanceDFCovars,  # noqa
    BalanceDFOutcomes,  # noqa
    BalanceDFOutcomesHat,  # noqa
    BalanceDFSource,  # noqa
    BalanceDFWeights,  # noqa
)
from balance.datasets import load_data  # noqa
from balance.sample_class import Sample  # noqa
from balance.sample_frame import SampleFrame  # noqa
from balance.util import TruncationFormatter  # noqa

# pyrefly: ignore [unknown-name]
global __version__
__version__ = "0.24.0"

WELCOME_MESSAGE = f"""
balance (Version {__version__}) loaded:
    📖 Documentation: https://import-balance.org/
    🛠️ Help / Issues: https://github.com/facebookresearch/balance/issues/
    📄 Citation:
        Sarig, T., Galili, T., & Eilat, R. (2023).
        balance - a Python package for balancing biased data samples.
        https://arxiv.org/abs/2307.06024

    Tip: You can view this message anytime with balance.help()
"""


def help() -> None:
    """Display information about documentation, help, and citation.

    This function provides users with quick access to important resources
    including documentation links, issue tracking, and citation information.
    """
    print(WELCOME_MESSAGE)


def setup_logging(
    logger_name: str | None = __package__,
    level: str = "INFO",
    removeHandler: bool = True,
) -> logging.Logger:
    """
    Initiates a nicely formatted logger called "balance", with level "info".
    """
    if removeHandler:
        for handler in logging.root.handlers[:]:
            logging.root.removeHandler(handler)

    logger = logging.getLogger(logger_name)

    logger.setLevel(getattr(logging, level))
    formatter = TruncationFormatter(
        "%(levelname)s (%(asctime)s) [%(module)s/%(funcName)s (line %(lineno)d)]: %(message)s"
    )
    handler = logging.StreamHandler()
    handler.setFormatter(formatter)
    logger.addHandler(handler)

    return logger


logger: logging.Logger = setup_logging()
logger.info(f"Using {__package__} version {__version__}")

# Log the welcome/help/citation message on import (use logger.info instead
# of print to avoid unwanted output when balance is imported in production
# pipelines).
logger.info(WELCOME_MESSAGE)


def set_warnings(level: str = "WARNING") -> None:
    logger.setLevel(getattr(logging, level))
