# Copyright (c) Meta Platforms, Inc. and affiliates.
#
# This source code is licensed under the MIT license found in the
# LICENSE file in the root directory of this source tree.


from __future__ import annotations

import logging
from typing import Any, Optional, Tuple, Union

import numpy as np
import numpy.typing as npt
import pandas as pd
from balance.stats_and_plots.weights_stats import _check_weights_are_valid
from balance.util import model_matrix, rm_mutual_nas
from balance.utils.input_validation import _assert_type
from scipy.stats import norm
from statsmodels.stats.weightstats import DescrStatsW

logger: logging.Logger = logging.getLogger(__package__)


##########################################
# Weighted statistics
##########################################


def _prepare_weighted_stat_args(
    v: list[Any] | pd.Series | pd.DataFrame | npt.NDArray | np.matrix,
    w: list[Any] | pd.Series | npt.NDArray | None = None,
    inf_rm: bool = False,
) -> Tuple[pd.DataFrame, pd.Series]:
    """
    Checks that the values (v) and weights (w) are of the supported types and of the same length. Can also replace np.Inf to np.nan.

    Args:
        v (Union[List, pd.Series, pd.DataFrame, np.ndarray, np.matrix,]): a series of values. Notice that pd.DataFrame and np.matrix should store the Series/np.ndarry as columns (not rows).
        w (Union[List, pd.Series, np.ndarray, None]): a series of weights to be used with v (could also be none). Defaults to None.
        inf_rm (bool, optional): should np.inf values be replaced by np.nan? Defaults to False.

    Returns:
        Tuple[pd.DataFrame, pd.Series]: the original v and w after they have been validated, and turned to pd.DataFrame and pd.Series (if needed).
        The values might be int64 or float64, depending on the input.
    """

    supported_types = (
        list,
        pd.Series,
        np.ndarray,
    )

    tmp_supported_types = supported_types + (
        pd.DataFrame,
        np.matrix,
    )
    if type(v) not in tmp_supported_types:
        raise TypeError(f"argument must be {tmp_supported_types}, is {type(v)}")

    tmp_supported_types = supported_types + (type(None),)
    if type(w) not in supported_types + (type(None),):
        raise TypeError(f"argument must be {tmp_supported_types}, is {type(w)}")

    # NOTE: np.matrix is an instance of np.ndarray, so we must turn it to pd.Dataframe before moving forward.
    if isinstance(v, np.matrix):
        v = pd.DataFrame(v)
    if isinstance(v, np.ndarray):
        # Check if it's a 2D array (matrix-like)
        if v.ndim == 2:
            v = pd.DataFrame(v)
        else:
            v = pd.Series(v)
    elif isinstance(v, list):
        v = pd.Series(v)
    if isinstance(v, pd.Series):
        v = v.to_frame()
    if isinstance(w, np.ndarray) or isinstance(w, list):
        w = pd.Series(w)
    if w is None:
        w = pd.Series(np.ones(len(v)), index=v.index)

    if v.shape[0] != w.shape[0]:
        raise ValueError(
            f"weights (w) and data (v) must have same number of rows, ({v.shape[0]}, {w.shape[0]})"
        )

    dtypes = v.dtypes if hasattr(v.dtypes, "__iter__") else [v.dtypes]

    if not all(pd.api.types.is_numeric_dtype(x) for x in dtypes):
        raise TypeError("all columns must be numeric")

    if inf_rm:
        from balance.util import _safe_replace_and_infer

        # Since v is guaranteed to be DataFrame and w is guaranteed to be Series at this point,
        # we can safely cast the results
        v = _safe_replace_and_infer(v)
        # pyrefly: ignore [bad-assignment]
        w = _safe_replace_and_infer(w)

    v = v.reset_index(drop=True)
    # pyrefly: ignore [missing-attribute]
    w = w.reset_index(drop=True)

    _check_weights_are_valid(w)

    # Type cast to satisfy pyre - we know these are correct types based on the function logic
    return pd.DataFrame(v), pd.Series(w)


def weighted_mean(
    v: list[Any] | pd.Series | pd.DataFrame | np.matrix,
    w: list[Any] | pd.Series | npt.NDArray | None = None,
    inf_rm: bool = False,
) -> pd.Series:
    """
    Computes the weighted average of a pandas Series or DataFrame.

    If no weights are supplied, it just computes the simple arithmetic mean.

    See:
    https://en.wikipedia.org/wiki/Weighted_arithmetic_mean

    Uses :func:`_prepare_weighted_stat_args`.

    Args:
        v (Union[ List, pd.Series, pd.DataFrame, np.matrix, ]): values to average.
            Missing values (None, np.nan, or pd.NA) and their weights are omitted
            separately for each column. Real zeros remain observations.
        w (Union[ List, pd.Series], optional): weights. Defaults to None.
            Rows with missing weights are omitted from every column.
        inf_rm (bool, optional): whether to remove infinite (from weights or values) from the computation. Defaults to False.

    Returns:
        pd.Series(dtype=np.float64): The weighted mean.
        If v is a DataFrame with several columns than the pd.Series will have a value for the weighted mean of each of the columns.
        If inf_rm=False then:
            If v has Inf then the output will be Inf.
            If w has Inf then the output will be np.nan.

    Examples:
    .. code-block:: python
            from balance.stats_and_plots.weighted_stats import weighted_mean

            weighted_mean(pd.Series((1, 2, 3, 4)))
                # 0    2.5
                # dtype: float64

            weighted_mean(pd.Series((1, 2, 3, 4)), pd.Series((1, 2, 3, 4)))
                # 0    3.0
                # dtype: float64

            df = pd.DataFrame(
                {"a": [1,2,3,4], "b": [1,1,1,1]}
            )
            w = pd.Series((1, 2, 3, 4))
            weighted_mean(df, w)
                # a    3.0
                # b    1.0
                # dtype: float64
    """
    v, w = _prepare_weighted_stat_args(v, w, inf_rm)
    observed_weights = v.notna().multiply(w, axis="index")
    return v.multiply(w, axis="index").sum() / observed_weights.sum()


def var_of_weighted_mean(
    v: list[Any] | pd.Series | pd.DataFrame | np.matrix,
    w: list[Any] | pd.Series | npt.NDArray | None = None,
    inf_rm: bool = False,
) -> pd.Series:
    """
    Computes the variance of the weighted average (pi estimator for ratio-mean) of a list of values and their corresponding weights.

    If no weights are supplied, it assumes that all values have equal weights of 1.0.

    See: https://en.wikipedia.org/wiki/Weighted_arithmetic_mean#Variance_of_the_weighted_mean_(%CF%80-estimator_for_ratio-mean)

    Uses :func:`_prepare_weighted_stat_args`.

    v (Union[List, pd.Series, pd.DataFrame, np.matrix]): A series of values.
        Missing values and their weights are omitted separately for each column,
        using the same observed rows as weighted_mean. Real zeros are retained.
    w (Optional[Union[List, pd.Series, np.ndarray]]): A series of weights to be used with `v`.
        Missing weights are omitted. If None, all values will be weighted equally.
    inf_rm (bool, optional): Whether to remove infinite (from weights or values) from the computation. Defaults to False.

    Returns:
        pd.Series: The variance of the weighted mean. If `v` is a DataFrame with several columns, the pd.Series will have a value for the weighted variance of each column. The values are of data type `np.float64`.
        If `inf_rm` is False:
            If `v` has infinite values, the output will be `Inf`.
            If `w` has infinite values, the output will be `np.nan`.


    Examples:
    .. code-block:: python

            from balance.stats_and_plots.weighted_stats import var_of_weighted_mean

            #  In R: sum((1:4 - mean(1:4))^2 / 4) / (4)
            #  [1] 0.3125
            var_of_weighted_mean(pd.Series((1, 2, 3, 4)))
                # pd.Series(0.3125)

            #  For a reproducible R example, see: https://gist.github.com/talgalili/b92cd8cdcbfc287e331a8f27db265c00
            var_of_weighted_mean(pd.Series((1, 2, 3, 4)), pd.Series((1, 2, 3, 4)))
                # pd.Series(0.24)

            df = pd.DataFrame(
                {"a": [1,2,3,4], "b": [1,1,1,1]}
            )
            w = pd.Series((1, 2, 3, 4))
            var_of_weighted_mean(df, w)

                # a    0.24
                # b    0.00
                # dtype: float64
    """
    v, w = _prepare_weighted_stat_args(v, w, inf_rm)
    observed_weights = v.notna().multiply(w, axis="index")
    weighed_mean_of_v = weighted_mean(v, w, inf_rm)  # This is a pd.Series
    # NOTE: the multiply needs to be called from the pd.Series. Unfortunately this makes the code less readable.
    sum_of_squared_weighted_diffs = (
        ((v - weighed_mean_of_v).multiply(w, axis="index")).pow(2).sum()
    )
    squared_sum_of_w = observed_weights.sum() ** 2
    return sum_of_squared_weighted_diffs / squared_sum_of_w


def ci_of_weighted_mean(
    v: list[float] | pd.Series | pd.DataFrame | npt.NDArray,
    w: list[float] | pd.Series | npt.NDArray | None = None,
    conf_level: float = 0.95,
    round_ndigits: int | None = None,
    inf_rm: bool = False,
) -> pd.Series:
    """
    Computes the confidence interval of the weighted mean of a list of values and their corresponding weights.

    Missing values and missing weights are omitted per column by both
    weighted_mean and var_of_weighted_mean, so the center and uncertainty use
    the same observed rows. A column without observed positive weight returns
    a pair of NaNs.

    If no weights are supplied, it assumes that all values have equal weights of 1.0.

    v (Union[List[float], pd.Series, pd.DataFrame, np.ndarray]): A series of values. If v is a DataFrame, the weighted mean and its confidence interval will be calculated for each column using the same set of weights from `w`.
    w (Optional[Union[List[float], pd.Series, np.ndarray]]): A series of weights to be used with `v`. If None, all values will be weighted equally.
    conf_level (float, optional): Confidence level for the interval, between 0 and 1. Defaults to 0.95.
    round_ndigits (Optional[int], optional): Number of decimal places to round the confidence interval. If None, the values will not be rounded. Defaults to None.
    inf_rm (bool, optional): Whether to remove infinite (from weights or values) from the computation. Defaults to False.

    Returns:
        pd.Series: The confidence interval of the weighted mean. If `v` is a DataFrame with several columns, the pd.Series will have a value for the confidence interval of each column. The values are of data type Tuple[np.float64, np.float64].
        If `inf_rm` is False:
            If `v` has infinite values, the output will be `Inf`.
            If `w` has infinite values, the output will be `np.nan`.

    Examples:
    .. code-block:: python

            from balance.stats_and_plots.weighted_stats import ci_of_weighted_mean

            ci_of_weighted_mean(pd.Series((1, 2, 3, 4)))
                # 0    (1.404346824279273, 3.5956531757207273)
                # dtype: object

            ci_of_weighted_mean(pd.Series((1, 2, 3, 4)), round_ndigits = 3).to_list()
                # [(1.404, 3.596)]

            ci_of_weighted_mean(pd.Series((1, 2, 3, 4)), pd.Series((1, 2, 3, 4)))
                # 0    (2.039817664728938, 3.960182335271062)
                # dtype: object

            ci_of_weighted_mean(pd.Series((1, 2, 3, 4)), pd.Series((1, 2, 3, 4)), round_ndigits = 3).to_list()
                # [(2.04, 3.96)]

            df = pd.DataFrame(
                {"a": [1,2,3,4], "b": [1,1,1,1]}
            )
            w = pd.Series((1, 2, 3, 4))
            ci_of_weighted_mean(df, w, conf_level = 0.99, round_ndigits = 3)
                # a    (1.738, 4.262)
                # b        (1.0, 1.0)
                # dtype: object
            ci_of_weighted_mean(df, w, conf_level = 0.99, round_ndigits = 3).to_dict()
                # {'a': (1.738, 4.262), 'b': (1.0, 1.0)}
    """
    v, w = _prepare_weighted_stat_args(v, w, inf_rm)
    weighed_mean_of_v = weighted_mean(v, w, inf_rm)
    var_weighed_mean_of_v = var_of_weighted_mean(v, w, inf_rm)
    z_value = norm.ppf((1 + conf_level) / 2)

    # After _prepare_weighted_stat_args, v is always a DataFrame
    ci_index = v.columns

    ci = pd.Series(
        [
            (
                weighed_mean_of_v.iloc[i]
                - z_value * np.sqrt(var_weighed_mean_of_v.iloc[i]),
                weighed_mean_of_v.iloc[i]
                + z_value * np.sqrt(var_weighed_mean_of_v.iloc[i]),
            )
            for i in range(len(weighed_mean_of_v))
        ],
        index=ci_index,
    )

    if round_ndigits is not None:
        # Apply a lambda function to round a pd.Series of tuples to x decimal places
        ci = ci.apply(lambda t: tuple(round(x, round_ndigits) for x in t))

    return _assert_type(ci, pd.Series)


def weighted_var(
    v: list[Any] | pd.Series | pd.DataFrame | npt.NDArray | np.matrix,
    w: list[Any] | pd.Series | npt.NDArray | None = None,
    inf_rm: bool = False,
) -> pd.Series:
    """
    Calculate the sample weighted variance (a.k.a 'reliability weights').
    This is described here:
    https://en.wikipedia.org/wiki/Weighted_arithmetic_mean#Reliability_weights_2
    And also used in SDMTools, see:
    https://www.gnu.org/software/gsl/doc/html/statistics.html#weighted-samples

    Uses :func:`weighted_mean` and :func:`_prepare_weighted_stat_args`.

    Args:
        v (Union[ List, pd.Series, pd.DataFrame, np.matrix, ]): values to get the weighted variance for.
            Missing values and their weights are omitted separately for each
            column, using the same observed rows as weighted_mean. Real zeros
            are retained.
        w (Union[ List, pd.Series], optional): weights. Defaults to None.
            Rows with missing weights are omitted from every column.
        inf_rm (bool, optional): whether to remove infinite (from weights or values) from the computation. Defaults to False.

    Returns:
        pd.Series[np.float64]: The weighted variance.
        If v is a DataFrame with several columns than the pd.Series will have a value for the weighted mean of each of the columns.
        If inf_rm=False then:
            If v has Inf then the output will be Inf.
            If w has Inf then the output will be np.nan.

    Examples:
    .. code-block:: python

        import pandas as pd
        from balance.stats_and_plots.weighted_stats import weighted_var
        weighted_var(pd.DataFrame({"x": [1, 2, 3]}), [1, 1, 1]).tolist()
        # [1.0]
    """
    v, w = _prepare_weighted_stat_args(v, w, inf_rm)
    observed_weights = v.notna().multiply(w, axis="index")
    means = weighted_mean(v, w)
    v1 = observed_weights.sum()
    v2 = observed_weights.pow(2).sum()
    # Avoid divide by zero warning
    denominator = v1**2 - v2
    with np.errstate(divide="ignore", invalid="ignore"):
        result = (v1 / denominator) * ((v - means) ** 2).multiply(w, axis="index").sum()
    return result


def weighted_sd(
    v: list[Any] | pd.Series | pd.DataFrame | np.matrix,
    w: list[Any] | pd.Series | npt.NDArray | None = None,
    inf_rm: bool = False,
) -> pd.Series:
    """Calculate the sample weighted standard deviation

    See :func:`weighted_var` for details.

    Args:
        v (Union[ List, pd.Series, pd.DataFrame, np.matrix, ]): Values.
        w (Union[ List, pd.Series, np.ndarray, None, ], optional): Weights. Defaults to None.
        inf_rm (bool, optional): Remove inf. Defaults to False.

    Returns:
        pd.Series: np.sqrt of :func:`weighted_var` (np.float64)

    Examples:
    .. code-block:: python

        import pandas as pd
        from balance.stats_and_plots.weighted_stats import weighted_sd
        weighted_sd(pd.DataFrame({"x": [1, 2, 3]}), [1, 1, 1]).tolist()
        # [1.0]
    """
    return pd.Series(np.sqrt(weighted_var(v, w, inf_rm)))


def weighted_r2(
    y_true: list[Any] | pd.Series | npt.NDArray,
    y_pred: list[Any] | pd.Series | npt.NDArray,
    w: list[Any] | pd.Series | npt.NDArray | None = None,
    inf_rm: bool = False,
) -> float:
    """Computes the weighted coefficient of determination (weighted R²).

    Defined as ``1 - SS_res / SS_tot`` where
    ``SS_res = Σ wᵢ (yᵢ − ŷᵢ)²`` (weighted residual sum of squares) and
    ``SS_tot = Σ wᵢ (yᵢ − ȳ_w)²`` (weighted total sum of squares), with
    ``ȳ_w`` the :func:`weighted_mean` of ``y_true``.

    For a Gaussian/regression target this is also the (weighted) fraction of
    deviance explained. When no weights are supplied (or all weights are equal)
    this reduces to :func:`sklearn.metrics.r2_score`.

    See: https://en.wikipedia.org/wiki/Coefficient_of_determination

    Rows that are missing (NaN) or infinite in any of ``y_true``, ``y_pred``, or
    ``w`` are dropped before the computation (using :func:`rm_mutual_nas`),
    matching the mutual-NA handling of the other weighted-stats helpers.

    Args:
        y_true (Union[List, pd.Series, np.ndarray]): the observed target values.
        y_pred (Union[List, pd.Series, np.ndarray]): the predicted target values, aligned with ``y_true``.
        w (Union[List, pd.Series, np.ndarray, None], optional): weights to apply. If None, all rows are weighted equally (uniform weights of 1.0). Defaults to None.
        inf_rm (bool, optional): kept for signature parity with the other weighted-stats helpers. Infinite values in the inputs are always removed together with NaNs regardless of this flag. Defaults to False.

    Returns:
        float: the weighted R². Matches :func:`sklearn.metrics.r2_score` on the degenerate ``SS_tot == 0`` case: returns ``1.0`` when the predictions are perfect (``SS_res == 0``) and ``0.0`` otherwise.

    Examples:
    .. code-block:: python

            import pandas as pd
            from balance.stats_and_plots.weighted_stats import weighted_r2

            weighted_r2(
                pd.Series([1.0, 2.0, 3.0]),
                pd.Series([1.1, 1.9, 3.2]),
                w=pd.Series([1.0, 1.0, 2.0]),
            )
                # 0.9636363636363636

            # Without weights it matches sklearn.metrics.r2_score:
            weighted_r2(pd.Series([1.0, 2.0, 3.0]), pd.Series([1.1, 1.9, 3.2]))
                # 0.97
    """
    del inf_rm  # infinite values are always removed together with NaNs below
    if w is None:
        w = np.ones(len(y_true))

    y_true, y_pred, w = rm_mutual_nas(
        np.asarray(y_true, dtype=float),
        np.asarray(y_pred, dtype=float),
        np.asarray(w, dtype=float),
    )
    if len(y_true) == 0:
        # Every row was NaN/inf in some input; R² is undefined for empty input.
        return float("nan")
    _check_weights_are_valid(pd.Series(w))

    y_bar = weighted_mean(pd.Series(y_true), pd.Series(w)).iloc[0]
    ss_res = float(np.sum(w * (y_true - y_pred) ** 2))
    ss_tot = float(np.sum(w * (y_true - y_bar) ** 2))

    if ss_tot == 0:
        # Matches sklearn.metrics.r2_score: a constant y_true yields 1.0 when the
        # residuals are also zero (perfect prediction) and 0.0 otherwise.
        return 1.0 if ss_res == 0 else 0.0
    return 1.0 - ss_res / ss_tot


def weighted_quantile(
    v: list[Any] | pd.Series | pd.DataFrame | npt.NDArray | np.matrix,
    quantiles: float | list[Any] | pd.Series | npt.NDArray,
    w: list[Any] | pd.Series | npt.NDArray | None = None,
    inf_rm: bool = False,
) -> pd.DataFrame:
    """
    Calculates the weighted quantiles (q) of values (v) based on weights (w).

    See :func:`_prepare_weighted_stat_args` for the pre-processing done to v and w.

    Based on :func:`statsmodels.stats.weightstats.DescrStatsW`.

    Args:
        v (Union[ List, pd.Series, pd.DataFrame, np.array, np.matrix, ]): values to get the weighted quantiles for.
        quantiles (float | list | pd.Series | np.ndarray): A single quantile or a collection of quantiles to calculate.
        w (Union[ List, pd.Series, np.array, ] optional): weights. Defaults to None.
        inf_rm (bool, optional): whether to remove infinite (from weights or values) from the computation. Defaults to False.

    Returns:
        pd.DataFrame: The index (names p) has the values from quantiles. The columns are based on v:
            If it's a pd.Series it's one column, if it's a pd.DataFrame with several columns, than each column
            in the output corrosponds to the column in v.
            When weights contain no positive non-missing entry, every quantile
            is undefined and returned as NaN; weight validation emits a warning.

    Examples:
    .. code-block:: python

        from balance.stats_and_plots.weighted_stats import weighted_quantile
        weighted_quantile([1, 2, 3], [0.5], w=[1, 1, 1]).iloc[0, 0]
        # 2.0
    """

    v, w = _prepare_weighted_stat_args(v, w, inf_rm)
    quantiles = np.atleast_1d(quantiles)
    contributing = np.asarray(w.notna() & (w > 0), dtype=bool)
    if not contributing.any():
        return pd.DataFrame(
            np.nan,
            index=pd.Index(np.asarray(quantiles), name="p"),
            columns=[f"col{i + 1}" for i in range(v.shape[1])],
        )
    v = v.iloc[contributing]
    w = w.iloc[contributing]

    v = np.array(v)
    w = np.array(w)
    quantiles = np.array(quantiles)

    d = DescrStatsW(v.astype(float), weights=w)
    return d.quantile(quantiles)


def descriptive_stats(
    df: pd.DataFrame,
    weights: list[Any] | pd.Series | npt.NDArray | None = None,
    stat: str = "mean",
    # relevant only if stat is None
    weighted: bool = True,
    # relevant only if we have non-numeric columns and we want to use model_matrix on them
    numeric_only: bool = False,
    add_na: bool = True,
    formula: Optional[Union[str, list[str]]] = None,
    **kwargs: Any,
) -> pd.DataFrame:
    """Computes weighted statistics (e.g.: mean, std) on a DataFrame

    This function gets a DataFrame + weights and apply some weighted aggregation function (mean, std, or DescrStatsW).
    The main benefit of the function is that if the DataFrame includes non-numeric columns, then descriptive_stats will first
    run :func:`model_matrix` to create some numeric dummary variable that will then be processed.

    Args:
        df (pd.DataFrame): Some DataFrame to get stats (mean, std, etc.) for.
        weights (Union[ List, pd.Series, np.ndarray, ], optional): Weights to apply for the computation. Defaults to None.
        stat (str, optional): Which statistic to calculate on the data.
            If mean - uses :func:`weighted_mean` (with inf_rm=True)
            If std - uses :func:`weighted_sd` (with inf_rm=True)
            If var_of_mean - uses :func:`var_of_weighted_mean` (with inf_rm=True)
            If ci_of_mean - uses :func:`ci_of_weighted_mean` (with inf_rm=True)
            If something else - tries to use :func:`statsmodels.stats.weightstats.DescrStatsW`.
                This supports stat such as: std_mean, sum_weights, nobs, etc. See function documentation to see more.
                (while removing mutual nan using :func:`rm_mutual_nas`)
            Defaults to "mean".
        weighted (bool, optional): If stat is not "mean" or "std", if to use the weights with the DescrStatsW function.
            Defaults to True.
        numeric_only (bool, optional): Should the statistics be computed only on numeric columns?
            If True - then non-numeric columns will be omitted.
            If False - then :func:`model_matrix` (with no formula argument) will be used to transfer non-numeric columns to dummy variables.
            Defaults to False.
        add_na (bool, optional): Passed to :func:`model_matrix`.
            Relevant only if numeric_only == False and df has non-numeric columns.
            Defaults to True.
        formula (Optional[Union[str, List[str]]], optional): Formula passed to
            :func:`model_matrix`. When provided, the formula is always applied,
            allowing customization of which columns/dummies are used in the
            statistics (and taking precedence over numeric_only). Defaults to None.
        **kwargs: extra args to be passed to functions (e.g.: ci_of_weighted_mean)

    Returns:
        pd.DataFrame: Returns pd.DataFrame of the output (based on stat argument), for each of the columns in df.

    Examples:
    .. code-block:: python

            import numpy as np
            import pandas as pd
            from balance.stats_and_plots.weighted_stats import descriptive_stats, weighted_mean, weighted_sd

            # Without weights
            x = [1, 2, 3, 4]
            print(descriptive_stats(pd.DataFrame(x), stat="mean"))
            print(np.mean(x))
            print(weighted_mean(x))
                #     0
                # 0  2.5
                # 2.5
                # 0    2.5
                # dtype: float64

            print(descriptive_stats(pd.DataFrame(x), stat="var_of_mean"))
                #         0
                # 0  0.3125

            print(descriptive_stats(pd.DataFrame(x), stat="std"))
            print(weighted_sd(x))
            x2 = pd.Series(x)
            print(np.sqrt( np.sum((x2 - x2.mean())**2) / (len(x)-1) ))
                #         0
                # 0  1.290994
                # 0    1.290994
                # dtype: float64
                # 1.2909944487358056
                # Notice that it is different from
                # print(np.std(x))
                # which gives: 1.118033988749895
                # Which is the MLE (i.e.: biased, dividing by n and not n-1) estimator for std:
                # (np.sqrt( np.sum((x2 - x2.mean())**2) / (len(x)) ))

            x2 = pd.Series(x)
            tmp_sd = np.sqrt(np.sum((x2 - x2.mean()) ** 2) / (len(x) - 1))
            tmp_se = tmp_sd / np.sqrt(len(x))
            print(descriptive_stats(pd.DataFrame(x), stat="std_mean").iloc[0, 0])
            print(tmp_se)
                # 0.6454972243679029
                # 0.6454972243679028

            # Weighted results
            x, w = [1, 2, 3, 4], [1, 2, 3, 4]
            print(descriptive_stats(pd.DataFrame(x), w, stat="mean"))
                #      0
                # 0  3.0
            print(descriptive_stats(pd.DataFrame(x), w, stat="std"))
                #           0
                # 0  1.195229
            print(descriptive_stats(pd.DataFrame(x), w, stat="std_mean"))
                #           0
                # 0  0.333333
            print(descriptive_stats(pd.DataFrame(x), w, stat="var_of_mean"))
                #       0
                # 0  0.24
            print(descriptive_stats(pd.DataFrame(x), w, stat="ci_of_mean", conf_level = 0.99, round_ndigits=3))
                #                 0
                # 0  (1.738, 4.262)

            # Formula examples
            df = pd.DataFrame({"num": [1, 2, 3], "group": ["a", "b", "a"]})
            # Default formula includes all variables and encodes categoricals.
            print(descriptive_stats(df, stat="mean"))
                #    group[a]  group[b]  num
                # 0      0.67      0.33  2.0
            print(descriptive_stats(df, stat="mean", formula="num"))
                #     num
                # 0  2.0
            print(descriptive_stats(df, stat="mean", formula="group"))
                #    group[a]  group[b]
                # 0       0.67      0.33
            print(descriptive_stats(df, stat="mean", formula="num + group"))
                #    group[a]  group[b]  num
                # 0      0.67      0.33  2.0
            print(descriptive_stats(df, stat="mean", formula="num + group + num:group"))
                #    group[a]  group[b]  num  num:group[T.b]
                # 0      0.67      0.33  2.0            0.67

    """
    df = _assert_type(df, pd.DataFrame)
    if formula is not None:
        model_matrix_result = model_matrix(
            df, add_na=add_na, return_type="one", formula=formula
        )["model_matrix"]
        df = pd.DataFrame(model_matrix_result)
    elif len(df.select_dtypes(np.number).columns) != len(df.columns):
        # If we have non-numeric columns, and want faster results,
        # then we can set numeric_only == True.
        # This will skip the model_matrix computation for non-numeric variables.
        if numeric_only:
            # TODO: (p2) does this check takes a long time?
            #       if it does - then maybe add an option of numeric_only = None
            #       to just use df as is.
            df = df.select_dtypes(include=[np.number])
        else:
            model_matrix_result = model_matrix(df, add_na=add_na, return_type="one")[
                "model_matrix"
            ]
            df = pd.DataFrame(model_matrix_result)

    if stat == "mean":
        return weighted_mean(df, weights, inf_rm=True).to_frame().transpose()
    elif stat == "std":
        return weighted_sd(df, weights, inf_rm=True).to_frame().transpose()
    elif stat == "var_of_mean":
        return var_of_weighted_mean(df, weights, inf_rm=True).to_frame().transpose()
    elif stat == "ci_of_mean":
        conf_level = kwargs.get("conf_level", 0.95)
        round_ndigits = kwargs.get("round_ndigits", None)
        return (
            ci_of_weighted_mean(
                df,
                weights,
                inf_rm=True,
                conf_level=conf_level,
                round_ndigits=round_ndigits,
            )
            .to_frame()
            .transpose()
        )

    # TODO: (p2) check which input DescrStatsW takes, not sure we need to run the next two lines.
    if weights is not None:
        weights = pd.Series(weights)
    # TODO: (p2) consider to remove the "weighted" argument, and just use
    #       whatever is passed to "weights" (if None, than make sure it's replaced with 1s)
    #  Fallback to statsmodels function
    _check_weights_are_valid(weights)
    wdf = {}
    for c in df.columns.values:
        df_c, w = rm_mutual_nas(df.loc[:, c], weights)
        wdf[c] = [getattr(DescrStatsW(df_c, w if weighted else None), stat)]
    return pd.DataFrame(wdf)


def relative_frequency_table(
    df: pd.DataFrame | pd.Series,
    column: str | None = None,
    w: pd.Series | None = None,
) -> pd.DataFrame:
    """Creates a relative frequency table by aggregating over a categorical column (`column`) - optionally weighted by `w`.
    I.e.: produce the proportion (or weighted proportion) of rows that appear in each category, relative to the total number of rows (or sum of weights).
    See: https://en.wikipedia.org/wiki/Frequency_(statistics)#Types.

    Used in plotting functions.

    Args:
        df (pd.DataFrame): A DataFrame with categorical columns, or a pd.Series of the grouping column.
        column (Optional[str]): The name of the column to be aggregated.
            If None (default), then it takes the first column of df (if pd.DataFrame), or just uses as is (if pd.Series)
        w (Optional[pd.Series], optional): Optional weights to use when aggregating the relative proportions.
            If None than assumes weights is 1 for all rows. The defaults is None.

    Returns:
        pd.DataFrame: a pd.DataFrame with columns:
            - `column`, the aggregation variable, and,
            -  'prop', the aggregated (weighted) proportion of rows from each group in 'column'.

    Examples:
    .. code-block:: python

            from balance.stats_and_plots.weighted_stats import relative_frequency_table
            import pandas as pd

            df = pd.DataFrame({
                'group': ('a', 'b', 'c', 'c'),
                'v1': (1, 2, 3, 4),
            })
            print(relative_frequency_table(df, 'group'))
                #     group  prop
                #   0     a  0.25
                #   1     b  0.25
                #   2     c  0.50
            print(relative_frequency_table(df, 'group', pd.Series((2, 1, 1, 1),)))
                #     group  prop
                #   0     a   0.4
                #   1     b   0.2
                #   2     c   0.4

            # Using a pd.Series:
            a_series = df['group']
            print(relative_frequency_table(a_series))
                #   group  prop
                # 0     a  0.25
                # 1     b  0.25
                # 2     c  0.50
    """
    _check_weights_are_valid(w)

    if not (w is None or isinstance(w, pd.Series)):
        raise TypeError("argument `w` must be a pandas Series or None")
    if w is None:
        if not isinstance(df, (pd.DataFrame, pd.Series)):
            raise TypeError("argument `df` must be a pandas DataFrame or Series")
        w = pd.Series(np.ones(df.shape[0]), index=df.index)

    w = w.rename("Freq")

    if column is None:
        if isinstance(df, pd.DataFrame):
            column = df.columns.values[0]
        elif isinstance(df, pd.Series):
            if df.name is None:
                df.name = "group"
            # pyrefly: ignore [bad-assignment]
            column = df.name
        else:
            raise TypeError("argument `df` must be a pandas DataFrame or Series")

    relative_frequency_table_data = pd.concat((df, w), axis=1)

    relative_frequency_table_data = relative_frequency_table_data.groupby(
        column, as_index=False
    ).sum()
    relative_frequency_table_data["prop"] = relative_frequency_table_data["Freq"] / sum(
        relative_frequency_table_data["Freq"]
    )

    return relative_frequency_table_data.loc[:, (column, "prop")]
