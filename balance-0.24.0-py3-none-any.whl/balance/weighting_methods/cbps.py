# Copyright (c) Meta Platforms, Inc. and affiliates.
#
# This source code is licensed under the MIT license found in the
# LICENSE file in the root directory of this source tree.


from __future__ import annotations

import logging
from typing import Any, cast

import numpy as np
import numpy.typing as npt
import pandas as pd
import scipy
import sklearn.utils.extmath
import statsmodels.api as sm
from balance import adjustment as balance_adjustment, util as balance_util
from balance.stats_and_plots.weights_stats import design_effect
from balance.weighting_methods.ipw import _restore_dropped_rows
from scipy.sparse import csc_matrix
from scipy.special import expit

logger: logging.Logger = logging.getLogger(__package__)


def logit_truncated(
    X: npt.NDArray | pd.DataFrame,
    beta: npt.NDArray,
    truncation_value: float = 1e-5,
) -> npt.NDArray:
    """This is a helper function for cbps.
    Given an X matrx and avector of coeeficients beta, it computes the truncated
    version of the logit function.

    Truncation prevents numerical instabilities by bounding probabilities away from 0 and 1,
    which is essential for stable weight computation in propensity score methods.

    Args:
        X (Union[np.ndarray, pd.DataFrame]): Covariate matrix
        beta (np.ndarray): vector of coefficients
        truncation_value (float, optional): upper and lower bound for the computed probabilities. Defaults to 1e-5.

    Returns:
        np.ndarray: numpy array of computed probablities

    Examples:
    .. code-block:: python

        import numpy as np
        from balance.weighting_methods.cbps import logit_truncated
        logit_truncated(np.array([[0.0]]), np.array([0.0])).tolist()
        # [[0.5]]
    """
    probs = expit(np.matmul(X, beta))
    return np.minimum(np.maximum(probs, truncation_value), 1 - truncation_value)


def compute_pseudo_weights_from_logit_probs(
    probs: npt.NDArray,
    design_weights: npt.NDArray | pd.DataFrame,
    in_pop: npt.NDArray | pd.DataFrame,
) -> npt.NDArray:
    """This is a helper function for cbps.
    Given computed probs, it computes the weights: N/N_t * (in_pop - p_i)/(1 - p_i).
    (Note that these weights on sample are negative for convenience of notations)

    Args:
        probs (np.ndarray): vector of probabilities
        design_weights (Union[np.ndarray, pd.DataFrame]): vector of design weights of sample and target
        in_pop (Union[np.ndarray, pd.DataFrame]): indicator vector for target

    Returns:
        np.ndarray: np.ndarray of computed weights

    Examples:
    .. code-block:: python

        import numpy as np
        from balance.weighting_methods.cbps import compute_pseudo_weights_from_logit_probs
        probs = np.array([0.5, 0.5])
        design_weights = np.array([1.0, 1.0])
        in_pop = np.array([1.0, 0.0])
        compute_pseudo_weights_from_logit_probs(probs, design_weights, in_pop).tolist()
        # [2.0, -2.0]
    """
    N = np.sum(design_weights)
    N_target = np.sum(design_weights[in_pop == 1.0])
    return N / N_target * (in_pop - probs) / (1 - probs)


def bal_loss(
    beta: npt.NDArray,
    X: npt.NDArray,
    design_weights: npt.NDArray,
    in_pop: npt.NDArray,
    XtXinv: npt.NDArray,
) -> np.float64:
    """This is a helper function for cbps.
    It computes the balance loss.

    Args:
        beta (np.ndarray): vector of coefficients
        X (np.ndarray): Covariate matrix
        design_weights (np.ndarray): vector of design weights of sample and target
        in_pop (np.ndarray): indicator vector for target
        XtXinv (np.ndarray): (X.T %*% X)^(-1)

    Returns:
        np.float64: computed balance loss

    Examples:
    .. code-block:: python

        import numpy as np
        from balance.weighting_methods.cbps import bal_loss
        X = np.array([[1.0], [1.0]])
        beta = np.array([0.0])
        design_weights = np.array([1.0, 1.0])
        in_pop = np.array([1.0, 0.0])
        XtXinv = np.linalg.pinv(X.T @ X)
        float(bal_loss(beta, X, design_weights, in_pop, XtXinv)) >= 0
        # True
    """
    probs = logit_truncated(X, beta)
    N = np.sum(design_weights)
    weights = (
        1.0 / N * compute_pseudo_weights_from_logit_probs(probs, design_weights, in_pop)
    )

    Xprimew = np.matmul((X * design_weights[:, None]).T, weights)
    loss = np.absolute(np.matmul(np.matmul(Xprimew.T, XtXinv), Xprimew))

    return loss


def gmm_function(
    beta: npt.NDArray,
    X: npt.NDArray | pd.DataFrame,
    design_weights: npt.NDArray | pd.DataFrame,
    in_pop: npt.NDArray | pd.DataFrame,
    invV: npt.NDArray | None = None,
) -> dict[str, float | npt.NDArray]:
    """This is a helper function for cbps.
    It computes the gmm loss.

    Args:
        beta (np.ndarray): vector of coefficients
        X (Union[np.ndarray, pd.DataFrame]): covariates matrix
        design_weights (Union[np.ndarray, pd.DataFrame]): vector of design weights of sample and target
        in_pop (Union[np.ndarray, pd.DataFrame]): indicator vector for target
        invV (Union[np.ndarray, None], optional): the inverse weighting matrix for GMM. Default is None.

    Returns:
        Dict[str, Union[float, np.ndarray]]: Dict with two items for loss and invV:
            loss (float) computed gmm loss
            invV (np.ndarray) the weighting matrix for GMM

    Examples:
    .. code-block:: python

        import numpy as np
        from balance.weighting_methods.cbps import gmm_function
        X = np.array([[1.0], [1.0]])
        beta = np.array([0.0])
        design_weights = np.array([1.0, 1.0])
        in_pop = np.array([1.0, 0.0])
        result = gmm_function(beta, X, design_weights, in_pop)
        sorted(result.keys())
        # ['invV', 'loss']
    """
    # Convert inputs to numpy arrays to avoid pandas indexing issues
    if isinstance(X, pd.DataFrame):
        X = X.values
    if isinstance(design_weights, (pd.Series, pd.DataFrame)):
        design_weights = np.asarray(design_weights).flatten()
    if isinstance(in_pop, (pd.Series, pd.DataFrame)):
        in_pop = np.asarray(in_pop).flatten()

    probs = logit_truncated(X, beta)
    N = np.sum(design_weights)
    N_target = np.sum(design_weights[in_pop == 1.0])

    weights = compute_pseudo_weights_from_logit_probs(probs, design_weights, in_pop)

    # Generate gbar
    gbar = np.concatenate(
        (
            1.0 / N * (np.matmul((X * design_weights[:, None]).T, (in_pop - probs))),
            1.0 / N * (np.matmul((X * design_weights[:, None]).T, weights)),
        )
    )

    if invV is None:
        # Compute inverse sigma matrix to use in GMM estimate
        design_weights_sq = np.sqrt(design_weights)[:, None]
        X1 = design_weights_sq * X * np.sqrt((1 - probs) * probs)[:, None]
        X2 = design_weights_sq * X * np.sqrt(probs / (1 - probs))[:, None]
        X11 = design_weights_sq * X * np.sqrt(probs)[:, None]
        X11TX11 = np.matmul(X11.T, X11 * N / N_target)

        V = (
            1
            / N
            * np.vstack(
                (
                    np.hstack((np.matmul(X1.T, X1), X11TX11)),
                    np.hstack(
                        (X11TX11, np.matmul(X2.T, X2 * np.power(N / N_target, 2)))
                    ),
                )
            )
        )
        # Note - The R CBPS code is using sum(treat) for N_target instead of
        # the sum of the design weights on the treated
        invV = np.linalg.pinv(V)

    # Compute loss
    loss = np.matmul(np.matmul(gbar.T, invV), gbar)
    # pyrefly: ignore [bad-assignment]
    return {"loss": loss, "invV": invV}


def gmm_loss(
    beta: npt.NDArray,
    X: npt.NDArray | pd.DataFrame,
    design_weights: npt.NDArray | pd.DataFrame,
    in_pop: npt.NDArray | pd.DataFrame,
    invV: npt.NDArray | None = None,
) -> float | npt.NDArray:
    """This is a helper function for cbps.
    It computes the gmm loss.
    See gmm_function for detials.

    Args:
        beta (np.ndarray): vector of coefficients
        X (Union[np.ndarray, pd.DataFrame]): covariates matrix
        design_weights (Union[np.ndarray, pd.DataFrame]): vector of design weights of sample and target
        in_pop (Union[np.ndarray, pd.DataFrame]): indicator vector for target
        invV (Union[np.ndarray, None], optional): the inverse weighting matrix for GMM. Default is None.

    Returns:
        Union[float, np.ndarray]: loss (float) computed gmm loss

    Examples:
    .. code-block:: python

        import numpy as np
        from balance.weighting_methods.cbps import gmm_loss
        X = np.array([[1.0], [1.0]])
        beta = np.array([0.0])
        design_weights = np.array([1.0, 1.0])
        in_pop = np.array([1.0, 0.0])
        float(gmm_loss(beta, X, design_weights, in_pop)) >= 0
        # True
    """
    return gmm_function(beta, X, design_weights, in_pop, invV)["loss"]


def alpha_function(
    alpha: npt.NDArray,
    beta: npt.NDArray,
    X: npt.NDArray | pd.DataFrame,
    design_weights: npt.NDArray | pd.DataFrame,
    in_pop: npt.NDArray | pd.DataFrame,
) -> float | npt.NDArray:
    """This is a helper function for cbps.
    It computes the gmm loss of alpha*beta.

    Args:
        alpha (np.ndarray): multiplication factor
        beta (np.ndarray): vector of coefficients
        X (Union[np.ndarray, pd.DataFrame]): covariates matrix
        design_weights (Union[np.ndarray, pd.DataFrame]): vector of design weights of sample and target
        in_pop (Union[np.ndarray, pd.DataFrame]): indicator vector for target

    Returns:
        Union[float, np.ndarray]: loss (float) computed gmm loss

    Examples:
    .. code-block:: python

        import numpy as np
        from balance.weighting_methods.cbps import alpha_function
        X = np.array([[1.0], [1.0]])
        alpha = np.array([0.5])
        beta = np.array([1.0])
        design_weights = np.array([1.0, 1.0])
        in_pop = np.array([1.0, 0.0])
        float(alpha_function(alpha, beta, X, design_weights, in_pop)) >= 0
        # True
    """
    return gmm_loss(alpha * beta, X, design_weights, in_pop)


def compute_deff_from_beta(
    X: npt.NDArray, beta: npt.NDArray, design_weights: npt.NDArray, in_pop: npt.NDArray
) -> np.float64:
    """This is a helper function for cbps. It computes the design effect of
    the estimated weights on the sample given a value of beta.
    It is used for setting a constraints on max_de.

    Args:
        X (np.ndarray): covariates matrix
        beta (np.ndarray): vector of coefficients
        design_weights (np.ndarray): vector of design weights of sample and target
        in_pop (np.ndarray): indicator vector for target

    Returns:
        np.float64: design effect

    Examples:
    .. code-block:: python

        import numpy as np
        from balance.weighting_methods.cbps import compute_deff_from_beta
        X = np.array([[1.0], [1.0]])
        beta = np.array([0.0])
        design_weights = np.array([1.0, 1.0])
        in_pop = np.array([1.0, 0.0])
        float(compute_deff_from_beta(X, beta, design_weights, in_pop)) >= 0
        # True
    """
    probs = logit_truncated(X, beta)
    weights = np.absolute(
        compute_pseudo_weights_from_logit_probs(probs, design_weights, in_pop)
    )
    weights = design_weights[in_pop == 0.0] * weights[in_pop == 0.0]
    return design_effect(pd.Series(weights))


def _standardize_model_matrix(
    model_matrix: pd.DataFrame, model_matrix_columns_names: list[str]
) -> dict[str, Any]:
    """This is a helper function for cbps. It standardizes the columns of the model matrix.

    Args:
        model_matrix (pd.DataFrame): the matrix of covariates
        model_matrix_columns_names (List[str]): list of columns in the covariates matrix

    Returns:
        Dict[str, Any]: Dict of the shape
            {
                "model_matrix": model_matrix,
                "model_matrix_columns_names": model_matrix_columns_names,
                "model_matrix_mean": model_matrix_mean,
                "model_matrix_std": model_matrix_std,
            }
    """
    # TODO: Verify if scikit-learn have something similar
    model_matrix_std = np.asarray(np.std(model_matrix, axis=0)).reshape(
        -1
    )  # This is needed if the input is 2 dim numpy array
    if np.sum(model_matrix_std == 0) > 0:
        variables_to_omit = model_matrix_std == 0
        names_variables_to_omit = np.array(model_matrix_columns_names)[
            variables_to_omit
        ]
        logger.warning(
            f"The following variables have only one level, and are omitted: {names_variables_to_omit}"
        )
        model_matrix_columns_names = list(
            np.array(model_matrix_columns_names)[np.invert(variables_to_omit)]
        )
        model_matrix = model_matrix[:, np.invert(variables_to_omit)]
        model_matrix_std = model_matrix_std[np.invert(variables_to_omit)]
    model_matrix_mean = np.mean(model_matrix, axis=0)
    model_matrix = (model_matrix - model_matrix_mean) / model_matrix_std
    return {
        "model_matrix": model_matrix,
        "model_matrix_columns_names": model_matrix_columns_names,
        "model_matrix_mean": model_matrix_mean,
        "model_matrix_std": model_matrix_std,
    }


# TODO: update docs
def _reverse_svd_and_centralization(
    beta: npt.NDArray,
    U: npt.NDArray,
    s: npt.NDArray,
    Vh: npt.NDArray,
    X_matrix_mean: npt.NDArray,
    X_matrix_std: npt.NDArray,
) -> npt.NDArray:
    """This is a helper function for cbps. It revrse the svd and the centralization to get an estimate of beta
    Source: https://github.com/kosukeimai/CBPS/blob/master/R/CBPSMain.R#L353

    Args:
        beta (np.ndarray): coefficient vector
        U (np.ndarray): left singular vectors from SVD
        s (np.ndarray): singular values from SVD
        Vh (np.ndarray): right singular vectors from SVD
        X_matrix_mean (np.ndarray): mean of the model matrix
        X_matrix_std (np.ndarray): standard deviation of the model matrix

    Returns:
        np.ndarray: reversed beta coefficient vector
    """
    # TODO: update SVD and reverse SVD to the functions in scikit-learn
    # Invert s
    s_inv = s.copy()
    s_inv[s_inv > 1e-5] = 1 / s_inv[s_inv > 1e-5]
    s_inv[s_inv <= 1e-5] = 0
    # Compute beta
    beta = np.matmul(Vh.T * s_inv, beta)
    beta_new = np.delete(beta, 0) / X_matrix_std
    beta_new = np.insert(
        beta_new,
        0,
        beta[0,] - np.matmul(X_matrix_mean, beta_new),
    )
    return beta_new


def cbps(  # noqa
    sample_df: pd.DataFrame,
    sample_weights: pd.Series,
    target_df: pd.DataFrame,
    target_weights: pd.Series,
    variables: list[str] | None = None,
    transformations: str | None = "default",
    na_action: str = "add_indicator",
    formula: str | list[str] | None = None,
    balance_classes: bool = True,
    cbps_method: str = "over",  # other option: "exact"
    max_de: float | None = None,
    opt_method: str = "COBYLA",
    opt_opts: dict[str, Any] | None = None,
    weight_trimming_mean_ratio: None | float | int = 20,
    weight_trimming_percentile: float | None = None,
    random_seed: int = 2020,
    *args: Any,
    store_fit_metadata: bool = False,
    **kwargs: Any,
) -> dict[str, pd.Series | dict[str, Any]]:
    """Fit cbps (covariate balancing propensity score model) for the sample using the target.
    Final weights are normalized to target size.
    We use a two-step GMM estimator (as in the default R package), unlike the suggeted continuous-updating
    estimator in the paper. The reason is that it runs much faster than the continuous one.

    Paper: Imai, K., & Ratkovic, M. (2014). Covariate balancing propensity score.
    Journal of the Royal Statistical Society: Series B: Statistical Methodology, 243-263.
    https://rss.onlinelibrary.wiley.com/doi/abs/10.1111/rssb.12027
    R code source: https://github.com/kosukeimai/CBPS
    two-step GMM: https://en.wikipedia.org/wiki/Generalized_method_of_moments

    Args:
        sample_df (pd.DataFrame): a dataframe representing the sample
        sample_weights (pd.Series): design weights for sample
        target_df (pd.DataFrame): a dataframe representing the target
        target_weights (pd.Series): design weights for target
        variables (Optional[List[str]], optional): list of variables to include in the model.
            If None all joint variables of sample_df and target_df are used. Defaults to None.
        transformations (str, optional): what transformations to apply to data before fitting the model.
            Default is "default" (see apply_transformations function). Defaults to "default".
        na_action (str, optional): what to do with NAs. (see add_na_indicator function).
            Defaults to "add_indicator".
        formula (Optional[Union[str, List[str]]], optional): The formula according to which build the model.
            In case of list of formula, the model matrix will be built in steps and
            concatenated together.. Defaults to None.
        balance_classes (bool, optional): whether to balance the sample and target size for running the model.
            True is preferable for imbalanced cases. Defaults to True.
        cbps_method (str, optional): method used for cbps. "over" fits an over-identified model that combines
            the propensity score and covariate balancing conditions; "exact" fits a model that only c
            ontains the covariate balancing conditions. Defaults to "over".
        max_de (Optional[float], optional): upper bound for the design effect of the computed weights.
            Default is None.
        opt_method (str, optional): type of optimization solver. See :func:`scipy.optimize.minimize`
                   for other options. Defaults to "COBYLA".
        opt_opts (Optional[Dict], optional): A dictionary of solver options. Default is None. See :func:`scipy.optimize.minimize`
            for other options. Defaults to None.
        weight_trimming_mean_ratio (Union[None, float, int], optional): indicating the ratio from above according to which
            the weights are trimmed by mean(weights) * ratio. Defaults to 20.
            Set to None to use weight_trimming_percentile instead.
        weight_trimming_percentile (Optional[float], optional): percentile limit(s) for winsorization
            (see :func:`balance.adjustment.trim_weights`). Only one trimming option can be used,
            so passing it requires ``weight_trimming_mean_ratio=None``; otherwise a ValueError
            is raised. Defaults to None.
        random_seed (int, optional): a random seed. Defaults to 2020.
        store_fit_metadata (bool, optional): Whether to persist fit-time
            metadata required for downstream ``BalanceFrame.predict_weights()``
            reconstruction (for CBPS models), including the model-matrix
            builder's ``preprocessing_state`` result (``None`` when it does
            not provide one). Defaults to False.

    Raises:
        Exception: _description_
        Exception: _description_
        Exception: _description_
        Exception: _description_

    Returns:
        Dict[str, Union[pd.Series, Dict]]: A dictionary includes:
        "weight" --- The weights for the sample. Formula-omitted rows receive
            NaN weights at their original caller positions; raw-only
            ``na_action="drop"`` retains its historical compact return.
        "model" -- dictionary with details about the fitted model:
            X_matrix_columns, deviance, beta_optimal, balance_optimize_result,
            gmm_optimize_result_glm_init, gmm_optimize_result_bal_init
            It has the following shape:
            "model": {
                "method": "cbps",
                "X_matrix_columns": X_matrix_columns_names,
                "deviance": deviance,
                "original_sum_weights": original_sum_weights,  # This can be used to reconstruct the propensity probablities
                "beta_optimal": beta_opt,
                "beta_init_glm": beta_0,  # The initial estimator by glm
                "gmm_init": gmm_init,  # The rescaled initial estimator
                # The following are the results of the optimizations
                "rescale_initial_result": rescale_initial_result,
                "balance_optimize_result": balance_optimize_result,
                "gmm_optimize_result_glm_init": gmm_optimize_result_glm_init
                if cbps_method == "over"
                else None,
                "gmm_optimize_result_bal_init": gmm_optimize_result_bal_init
                if cbps_method == "over"
                else None,
            },

    Examples:
    .. code-block:: python

        import pandas as pd
        from balance.weighting_methods.cbps import cbps
        sample_df = pd.DataFrame({"x": [0, 1, 0, 1]})
        target_df = pd.DataFrame({"x": [0, 1, 0, 1]})
        sample_weights = pd.Series([1.0, 1.0, 1.0, 1.0])
        target_weights = pd.Series([1.0, 1.0, 1.0, 1.0])
        result = cbps(
            sample_df,
            sample_weights,
            target_df,
            target_weights,
            variables=["x"],
            transformations=None,
            balance_classes=False,
        )
        len(result["weight"]) == len(sample_df)
        # True
    """

    logger.info("Starting cbps function")
    balance_adjustment._check_single_trimming_option(
        "cbps", weight_trimming_mean_ratio, weight_trimming_percentile
    )
    np.random.seed(random_seed)  # setting random seed for cases of variations in glmnet

    balance_util._check_weighting_methods_input(sample_df, sample_weights, "sample")
    balance_util._check_weighting_methods_input(target_df, target_weights, "target")

    # Choose joint variables from sample and target
    variables = balance_util.choose_variables(sample_df, target_df, variables=variables)
    logger.debug(f"Joint variables for sample and target: {variables}")

    sample_df = sample_df.loc[:, variables]
    target_df = target_df.loc[:, variables]
    sample_input_index = sample_df.index.copy()
    target_input_index = target_df.index.copy()
    sample_rows = np.arange(len(sample_df))
    target_rows = np.arange(len(target_df))

    if na_action == "drop":
        sample_rows = np.flatnonzero(sample_df.notna().all(axis=1))
        target_rows = np.flatnonzero(target_df.notna().all(axis=1))
        sample_df, sample_weights = balance_util.drop_na_rows(
            sample_df, sample_weights, "sample"
        )
        target_df, target_weights = balance_util.drop_na_rows(
            target_df, target_weights, "target"
        )
    # keeping index of sample df to use for final weights
    sample_index = sample_df.index

    # Applying transformations
    # Important! Variables that don't need transformations
    # should be transformed with the *identity function*,
    # otherwise will be dropped from the model
    sample_df, target_df = balance_adjustment.apply_transformations(
        (sample_df, target_df), transformations=transformations
    )
    variables = list(sample_df.columns)
    logger.debug(f"Final variables in the model: {variables}")

    # Build X matrix
    model_matrix_output = balance_util.model_matrix(
        sample_df,
        target_df,
        variables,
        add_na=(na_action == "add_indicator"),
        return_type="one",
        return_var_type="sparse",
        formula=formula,
        one_hot_encoding=False,
    )
    matrix_sample_rows = np.asarray(
        model_matrix_output.get("sample_rows", np.arange(len(sample_df))), dtype=int
    )
    matrix_target_rows = np.asarray(
        model_matrix_output.get("target_rows", np.arange(len(target_df))), dtype=int
    )
    matrix_rows_dropped = len(matrix_sample_rows) != len(sample_df) or len(
        matrix_target_rows
    ) != len(target_df)
    sample_df = sample_df.iloc[matrix_sample_rows]
    target_df = target_df.iloc[matrix_target_rows]
    sample_weights = sample_weights.iloc[matrix_sample_rows]
    target_weights = target_weights.iloc[matrix_target_rows]
    sample_rows = sample_rows[matrix_sample_rows]
    target_rows = target_rows[matrix_target_rows]
    sample_index = sample_df.index
    if matrix_rows_dropped and (len(sample_rows) == 0 or len(target_rows) == 0):
        raise ValueError(
            "Formula row dropping left an empty sample or target; "
            "CBPS fitting requires retained rows in both populations."
        )
    if (
        len(sample_rows) != len(sample_input_index)
        or len(target_rows) != len(target_input_index)
    ) and (
        not np.isfinite(sample_weights.sum())
        or sample_weights.sum() <= 0
        or not np.isfinite(target_weights.sum())
        or target_weights.sum() <= 0
    ):
        raise ValueError(
            "Row dropping left non-positive or non-finite sample or target weight mass; "
            "CBPS fitting requires positive finite retained weight sums."
        )
    X_matrix = cast(
        csc_matrix,
        (model_matrix_output["model_matrix"]),
    ).toarray()
    X_matrix_columns_names = cast(
        list[str], model_matrix_output["model_matrix_columns_names"]
    )
    logger.info(
        f"The formula used to build the model matrix: {model_matrix_output['formula']}"
    )

    # Standardize the X_matrix for SVD
    model_matrix_standardized = _standardize_model_matrix(
        X_matrix,
        X_matrix_columns_names,
    )
    X_matrix = model_matrix_standardized["model_matrix"]
    X_matrix_columns_names = model_matrix_standardized["model_matrix_columns_names"]
    logger.info(f"The number of columns in the model matrix: {X_matrix.shape[1]}")
    logger.info(f"The number of rows in the model matrix: {X_matrix.shape[0]}")

    # Adding intercept since model_matrix removes it
    X_matrix = np.c_[np.ones(X_matrix.shape[0]), X_matrix]
    X_matrix_columns_names.insert(0, "Intercept")

    # SVD for X_matrix
    U, s, Vh = scipy.linalg.svd(X_matrix, full_matrices=False)

    # remove near-zero singular values to address the rank-deficiency of X_matrix
    singular_value_threshold = 1e-10
    U = U[:, s > singular_value_threshold]
    Vh = Vh[s > singular_value_threshold, :]
    s = s[s > singular_value_threshold]

    # Make the sign of the SVD deterministic
    U, Vh = sklearn.utils.extmath.svd_flip(U, Vh, u_based_decision=False)

    sample_n = sample_df.shape[0]
    target_n = target_df.shape[0]
    total_n = sample_n + target_n

    # Create "treatment" (in_sample) variable
    in_sample = np.concatenate((np.ones(sample_n), np.zeros(target_n)))
    in_pop = np.concatenate((np.zeros(sample_n), np.ones(target_n)))
    if len(np.unique(in_sample.reshape(in_sample.shape[0]))) == 1:
        _number_unique = np.unique(in_sample.reshape(in_sample.shape[0]))
        raise Exception(
            f"Sample indicator only has value {_number_unique}. This can happen when your sample or target are empty from unknown reason"
        )

    # balance classes
    if balance_classes:
        design_weights = cast(
            npt.NDArray,
            total_n
            / 2
            * np.concatenate(
                (
                    sample_weights / np.sum(sample_weights),
                    target_weights / np.sum(target_weights),
                )
            ),
        )

        XtXinv = np.linalg.pinv(
            np.matmul((U * design_weights[:, None]).T, U * design_weights[:, None])
        )
    else:
        design_weights = np.concatenate((sample_weights, target_weights))
        design_weights = design_weights / np.mean(design_weights)
        XtXinv = np.linalg.pinv(np.matmul(U.T, U))

    # Define constraints for optimization to limit max_de
    constraints = []
    if max_de is not None:
        constraints += [
            # max de effect
            {
                "type": "ineq",
                "fun": lambda x: (
                    max_de - compute_deff_from_beta(U, x, design_weights, in_pop)
                ),
            }
        ]

    # Optimization using Generalized Methods of Moments:
    # Step 0 - initial estimation for beta
    logger.info("Finding initial estimator for GMM optimization")
    glm_mod = sm.GLM(
        in_pop, U, family=sm.families.Binomial(), freq_weights=design_weights
    )
    beta_0 = glm_mod.fit().params
    # TODO: add some safty for when this fails?

    # Step 1 - rescale initial estimation for beta by minimizing the gmm loss
    rescale_initial_result = scipy.optimize.minimize(
        alpha_function,
        x0=[1],
        args=(
            beta_0,
            U,
            design_weights,
            in_pop,
        ),
        bounds=[(0.8, 1.1)],  # These are the bounds used in the R CBPS package
    )
    if rescale_initial_result["success"] is np.bool_(False):
        logger.warning(
            f"Convergence of alpha_function has failed due to '{rescale_initial_result['message']}'"
        )
    gmm_init = beta_0 * rescale_initial_result["x"][0]
    invV = gmm_function(gmm_init, U, design_weights, in_pop, invV=None)["invV"]

    # Step 2 - find initial estimation for beta by minimizing balance loss
    logger.info(
        "Finding initial estimator for GMM optimization that minimizes the balance loss"
    )
    balance_optimize_result = scipy.optimize.minimize(
        fun=bal_loss,
        x0=gmm_init,
        args=(
            U,
            design_weights,
            in_pop,
            XtXinv,
        ),
        method=opt_method,
        options=opt_opts,
        constraints=constraints,
    )
    if balance_optimize_result["success"] is np.bool_(False):
        logger.warning(
            f"Convergence of bal_loss function has failed due to '{balance_optimize_result['message']}'"
        )
    beta_balance = balance_optimize_result["x"]

    gmm_optimize_result_glm_init = None
    gmm_optimize_result_bal_init = None
    if cbps_method == "exact":
        if (
            balance_optimize_result["success"] is np.bool_(False)
            and "Did not converge to a solution satisfying the constraints"
            in balance_optimize_result["message"]
        ):
            raise Exception("There is no solution satisfying the constraints.")
        beta_opt = beta_balance

    # Step 3 - minimize gmm_loss from two starting points: beta_balance and gmm_init,
    # and choose the solution that minimize the gmm_loss.
    elif cbps_method == "over":
        logger.info("Running GMM optimization")
        gmm_optimize_result_glm_init = scipy.optimize.minimize(
            fun=gmm_loss,
            x0=gmm_init,
            args=(
                U,
                design_weights,
                in_pop,
                invV,
            ),
            method=opt_method,
            options=opt_opts,
            constraints=constraints,
        )
        if gmm_optimize_result_glm_init["success"] is np.bool_(False):
            logger.warning(
                f"Convergence of gmm_loss function with gmm_init start point has failed due to '{gmm_optimize_result_glm_init['message']}'"
            )

        gmm_optimize_result_bal_init = scipy.optimize.minimize(
            fun=gmm_loss,
            x0=beta_balance,
            args=(
                U,
                design_weights,
                in_pop,
                invV,
            ),
            method=opt_method,
            options=opt_opts,
            constraints=constraints,
        )
        if gmm_optimize_result_bal_init["success"] is np.bool_(False):
            logger.warning(
                f"Convergence of gmm_loss function with beta_balance start point has failed due to '{gmm_optimize_result_bal_init['message']}'"
            )

        # If the constraints cannot be satisfied, exit the function
        if (
            gmm_optimize_result_glm_init["success"] is np.bool_(False)
            and "Did not converge to a solution satisfying the constraints"
            in gmm_optimize_result_glm_init["message"]
            and gmm_optimize_result_bal_init["success"] is np.bool_(False)
            and "Did not converge to a solution satisfying the constraints"
            in gmm_optimize_result_bal_init["message"]
        ):
            raise Exception("There is no solution satisfying the constraints.")

        # Choose beta that gives a smaller loss in GMM and that satisfy the constraints
        if (
            gmm_optimize_result_bal_init["fun"] < gmm_optimize_result_glm_init["fun"]
            and "Did not converge to a solution satisfying the constraints"
            not in gmm_optimize_result_bal_init["message"]
        ):
            beta_opt = gmm_optimize_result_bal_init["x"]
        else:
            beta_opt = gmm_optimize_result_glm_init["x"]

    else:
        raise Exception(f"cbps_method '{cbps_method}' is not a valid option")

    # Compute final probs and weights with beta_opt
    probs = logit_truncated(U, beta_opt)
    logger.debug(f"Minimum probs for sample: {np.min(probs[in_sample == 1.0])}")
    logger.debug(f"Maximum probs for sample: {np.max(probs[in_sample == 1.0])}")
    weights = np.absolute(
        compute_pseudo_weights_from_logit_probs(probs, design_weights, in_pop)
    )
    logger.debug(f"Minimum weight for sample: {np.min(weights[in_sample == 1.0])}")
    logger.debug(f"Maximum weight for sample: {np.max(weights[in_sample == 1.0])}")
    weights = design_weights[in_sample == 1.0] * weights[in_sample == 1.0]

    # Compute deviance (Minus twice the log-likelihood of the CBPS fit)
    deviance = -2 * np.sum(
        in_pop * design_weights * np.log(probs)
        + (1 - in_pop) * design_weights * np.log(1 - probs)
    )

    # trim weights
    weights = balance_adjustment.trim_weights(
        weights, weight_trimming_mean_ratio, weight_trimming_percentile
    )
    # normalize to target size
    original_sum_weights = np.sum(weights)
    logger.debug(f"original sum of weights for sample: {original_sum_weights}")
    weights = weights / original_sum_weights * np.sum(target_weights)

    # set index to sample_df
    weights = pd.DataFrame({"weight": weights}).set_index(sample_index)["weight"]

    if np.unique(weights).shape[0] == 1 or weights.describe()["std"] < 1e-4:
        # All weights are the same
        logger.warning(
            "All weights are identical (or almost identical). The estimates will not be adjusted"
        )

    beta_opt_model_space = beta_opt.copy()

    # Reverse SVD and centralization
    beta_opt = _reverse_svd_and_centralization(
        beta_opt_model_space,
        U,
        s,
        Vh,
        model_matrix_standardized["model_matrix_mean"],
        model_matrix_standardized["model_matrix_std"],
    )

    out = {
        "weight": (
            _restore_dropped_rows(weights, sample_rows, sample_input_index)
            if matrix_rows_dropped
            else weights
        ),
        "model": {
            "method": "cbps",
            "X_matrix_columns": X_matrix_columns_names,
            "deviance": deviance,
            "original_sum_weights": original_sum_weights,  # This can be used to reconstruct the propensity probablities
            "beta_optimal": beta_opt,
            "beta_init_glm": beta_0,  # The initial estimator by glm
            "gmm_init": gmm_init,  # The rescaled initial estimator
            # The following are the results of the optimizations
            "rescale_initial_result": rescale_initial_result,
            "balance_optimize_result": balance_optimize_result,
            "gmm_optimize_result_glm_init": (
                gmm_optimize_result_glm_init if cbps_method == "over" else None
            ),
            "gmm_optimize_result_bal_init": (
                gmm_optimize_result_bal_init if cbps_method == "over" else None
            ),
        },
    }
    if store_fit_metadata:
        cast(dict[str, Any], out["model"]).update(
            {
                "variables": variables,
                "transformations": transformations,
                "na_action": na_action,
                "formula": model_matrix_output["formula"],
                "balance_classes": balance_classes,
                "weight_trimming_mean_ratio": weight_trimming_mean_ratio,
                "weight_trimming_percentile": weight_trimming_percentile,
                "sample_index": sample_index,
                "target_index": target_df.index,
                "sample_rows": sample_rows.copy(),
                "target_rows": target_rows.copy(),
                "sample_input_index": sample_input_index,
                "target_input_index": target_input_index,
                "training_sample_weights": sample_weights.copy(),
                "training_target_weights": target_weights.copy(),
                "model_matrix_mean": model_matrix_standardized["model_matrix_mean"],
                "model_matrix_std": model_matrix_standardized["model_matrix_std"],
                "beta_optimal_model_space": beta_opt_model_space,
                "svd_s": s.copy(),
                "svd_Vh": Vh.copy(),
                "preprocessing_state": model_matrix_output.get("preprocessing_state"),
                "store_fit_metadata": True,
            }
        )
    logger.info("Done cbps function")

    return out
